(function ($) {
    "use strict";

	// Preloder
	$(window).on('load', function() {

		$('#status').fadeOut();

		$('#preloader').delay(100).fadeOut('fast');

		$('body').delay(100).css({'overflow':'visible'});

		$('.all-portfolios').isotope({
			itemSelector:'.single-portfolio'
		});

		$('.portfolio-nav ul li').on('click', function(){
			$('.portfolio-nav ul li').removeClass('active-portfolio');
			$(this).addClass('active-portfolio');
			
			var selector = $(this).attr('data-filter');
			$('.all-portfolios').isotope({
				filter:selector
			});
			return false;
		});
	});
	
	$('.bxslider').bxSlider({
 			auto:true,
 	});
	
	//magnify popup jquery
    $('.popup-gallery').magnificPopup( {
        delegate: 'a.popup-link',
        type: 'image',
        tLoading: 'Loading image #%curr%...',
        mainClass: 'mfp-img-mobile',
        gallery: {
            enabled: true,
            navigateByImgClick: true,
            preload: [0, 1] // Will preload 0 - before current, and 1 after the current image
        }
        , image: {
            tError: '<a href="%url%">The image #%curr%</a> could not be loaded.',
            titleSrc: function(item) {
                return item.el.attr('title') + '<small>by Marsel Van Oosten</small>';
            }
        }
    });
	
	
})(jQuery);